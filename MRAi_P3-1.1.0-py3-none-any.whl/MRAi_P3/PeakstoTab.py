import argparse, os, sys, subprocess

def parse_showhdr(spec_path):
    # Run showhdr -verb
    try:
        text = subprocess.check_output(["showhdr", "-verb", str(spec_path)], text=True)
    except FileNotFoundError:
        sys.exit("Error: `showhdr` not found on PATH.")
    except subprocess.CalledProcessError as e:
        sys.exit(f"`showhdr -verb` failed: {e}")
    ND = None
    sz = {}; sw = {}; pfst = {}; plst = {}; nam = {}
    for line in text.splitlines():
        line = line.rstrip()
        if line.startswith("FILE:"):
            parts = line.split()
            ND = int(parts[parts.index("DIM:") + 1])
        if line.startswith("DATA SIZE:"):
            parts = line.split()
            for i in range(ND): sz[i+1] = float(parts[i-ND])
        if line.startswith("SW PPM:"):
            parts = line.split()
            for i in range(ND): sw[i+1] = float(parts[i-ND])
        if line.startswith("PPM FIRST:"):
            parts = line.split()
            for i in range(ND): pfst[i+1] = float(parts[i-ND])                
        if line.startswith("PPM LAST:"):
            parts = line.split()
            for i in range(ND): plst[i+1] = float(parts[i-ND])
        if line.startswith("NAME:"):
            parts = line.split()
            for i in range(ND): nam[i+1] = "HN" if "H" in str(parts[i - ND]) else str(parts[i-ND])[-1]
    return ND, sz, sw, pfst, plst, nam

def point_from_ppm(ppm, first_ppm, last_ppm, size):
    return ( (first_ppm - ppm) / (first_ppm - last_ppm) ) * (size - 1) + 1

def main(peaks_path,spec_path, out=None):
    ND, sz, sw, pfst, plst, nam = (parse_showhdr(spec_path))

    if out is None: out = os.path.splitext(peaks_path)[0] + '.tab'
    with open(out,"w") as out:
        # ----- Header (mirrors AWK) -----
        out.write(f"REMARK ROI {ND}D Peak Detection System, File: XXXX\n")

        # DATA lines: sizes are sz+2; upper ppm is plst - sw*2/sz
        def upper_ppm(axis): return plst[axis] - sw[axis] * 2.0 / sz[axis]

        out.write(f"DATA  X_AXIS {nam[1]:3s}          1   {int(sz[1])+2:3d}  {pfst[1]:9.3f}ppm {upper_ppm(1):9.3f}ppm\n")
        out.write(f"DATA  Y_AXIS {nam[2]:3s}          1   {int(sz[2])+2:3d}  {pfst[2]:9.3f}ppm {upper_ppm(2):9.3f}ppm\n")
        if ND == 2:
            VARS = ["INDEX","X_AXIS","Y_AXIS","DX","DY", "X_PPM","Y_PPM", "X_HZ","Y_HZ", "XW","YW","XW_HZ","YW_HZ", "X1","X3","Y1","Y3","HEIGHT","DHEIGHT","VOL","PCHI2","TYPE","ASS","CLUSTID","MEMCNT",]
            FMT = ("%5d %9.3f %9.3f %6.3f %6.3f %8.3f %8.3f %9.3f %9.3f %7.3f %7.3f %8.3f %8.3f %4d %4d %4d %4d %+e %+e %+e %.5f %d %s %4d %4d")
            out.write("VARS   " + " ".join(VARS) + "\n")
            out.write("FORMAT " + FMT.replace("%", "%%").replace("%% ", "% ").replace("%%", "%") + "\n")

        if ND == 3:
            VARS = ["INDEX","X_AXIS","Y_AXIS","Z_AXIS","DX","DY","DZ", "X_PPM","Y_PPM","Z_PPM", "X_HZ","Y_HZ","Z_HZ", "XW","YW","ZW","XW_HZ","YW_HZ","ZW_HZ", "X1","X3","Y1","Y3","Z1","Z3", "HEIGHT","DHEIGHT","VOL","PCHI2","TYPE","ASS","CLUSTID","MEMCNT",]
            FMT = ("%5d %9.3f %9.3f %9.3f %6.3f %6.3f %6.3f %8.3f %8.3f %8.3f %9.3f %9.3f %9.3f %7.3f %7.3f %7.3f %8.3f %8.3f %8.3f %4d %4d %4d %4d %4d %4d %+e %+e %+e %.5f %d %s %4d %4d")
            out.write(f"DATA  Z_AXIS {nam[3]:3s}          1   {int(sz[3])+2:3d}  {pfst[3]:9.3f}ppm {upper_ppm(3):9.3f}ppm\n")
            out.write("VARS   " + " ".join(VARS) + "\n")
            out.write("FORMAT " + FMT.replace("%", "%%").replace("%% ", "% ").replace("%%", "%") + "\n")

        # ----- Read peaks; emit rows -----
        # CYANA/xeasy-like peak lines (skip headers; start after '#FORMAT xeasy')
        in_cyana = False
        with open(peaks_path,"r") as f:
            for raw in f:
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("#FORMAT xeasy"):
                    in_cyana = True
                    continue
                if not in_cyana:
                    continue
                parts = line.split()
                # need at least the 11 columns the AWK expects on peak rows
                if len(parts) < 11:
                    continue
                
                if ND == 3:
                    # 1:index  2:X  3:Y  4:Z  5:1  6:U  7:P  8:I  9:e  10:0  11:0  12:0  13:0
                    try:
                        n = int(float(parts[0]))
                        X = float(parts[1])
                        Y = float(parts[2])
                        Z = float(parts[3])
                        P = float(parts[6])  # HEIGHT in tab
                        I = float(parts[7])  # DHEIGHT (and VOL in AWK mapping)
                        A = str(parts[10])       # $(11) in AWK
                    except Exception:
                        continue
                        
                if ND == 2:
                    # 1:index  2:X  3:Y  4:1  5:U  6:P  7:I  8:e  9:0  10:0  11:0
                    try:
                        n = int(float(parts[0]))
                        X = float(parts[1])
                        Y = float(parts[2])
                        P = float(parts[5])  # HEIGHT in tab
                        I = float(parts[6])  # DHEIGHT (and VOL in AWK mapping)
                        A = str(parts[9])       # $(11) in AWK
                    except Exception:
                        continue

                # compute NMRPipe point indices (1-based)
                x_pnt = point_from_ppm(X, pfst[1], plst[1], sz[1])
                y_pnt = point_from_ppm(Y, pfst[2], plst[2], sz[2])
                if ND == 3: z_pnt = point_from_ppm(Z, pfst[3], plst[3], sz[3])

                # integer bounding box indices
                X1 = int(x_pnt); X3 = X1 + 1
                Y1 = int(y_pnt); Y3 = Y1 + 1
                if ND == 3: Z1 = int(z_pnt); Z3 = Z1 + 1

                # Build row in the order of VARS
                if ND == 3: row = [
                    n, x_pnt, y_pnt, z_pnt, 0.0, 0.0, 0.0,  # INDEX X/Y/Z_AXIS DX,DY,DZ
                    X, Y, Z, 0.0, 0.0, 0.0,                 # X/Y/Z_PPM X/Y/Z_HZ
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0,           # XW,YW,ZW XW_HZ,YW_HZ,ZW_HZ
                    X1, X3, Y1, Y3, Z1, Z3,                 # X1..Z3
                    P, 0.0, I, 0.0, 1, A, n, 1,             # HEIGHT, DHEIGHT, VOL, PCHI2, TYPE, ASS (string), CLUSTID, MEMCNT
                ]
                
                if ND == 2: row = [
                    n, x_pnt, y_pnt, 0.0, 0.0,              # INDEX X/Y_AXIS DX,DY
                    X, Y, 0.0, 0.0,                         # X/Y_PPM X/Y_HZ
                    0.0, 0.0, 0.0, 0.0,                     # XW,YW XW_HZ,YW_HZ
                    X1, X3, Y1, Y3,                         # X1..Y3
                    P, 0.0, I, 0.0, 1, A, n, 1,             # HEIGHT, DHEIGHT, VOL, PCHI2, TYPE, ASS (string), CLUSTID, MEMCNT
                ]

                out.write(FMT % tuple(row) + "\n")
                
if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Convert CYANA .peaks + showhdr -verb(spec) -> NMRPipe .tab")
    ap.add_argument("peaks", help="Path to CYANA .peaks file")
    ap.add_argument("-spec", required=True, help="Spectrum file to pass to `showhdr -verb` (e.g., HNCO.ft3 or .P3)")
    ap.add_argument("-o", default=None, help="Output file path (optional).")
    args = ap.parse_args()
    main(args.peaks, spec_path=args.spec,out=args.o)

