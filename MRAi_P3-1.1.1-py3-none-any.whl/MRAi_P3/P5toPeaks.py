import argparse, os, sys, subprocess
import numpy as np

def parse_showhdr(spec_path):
    # Run showhdr -verb
    try:
        text = subprocess.check_output(["showhdr", "-verb", str(spec_path)], text=True)
    except FileNotFoundError:
        # Fallback: use nmrglue to infer from Pipe dictionary
        import nmrglue as ng
        dic, _ = ng.pipe.read(str(spec_path))
        if "FDF2LABEL" not in dic:
            ND = 1
        elif float(dic.get("FDF3FTSIZE", 0)) > 1:
            ND = 3
        else:
            ND = 2
        labels = {}
        for i in range(1, ND + 1):
            key = f"FDF{i}LABEL"
            if key in dic:
                labels[i] = str(dic[key])
        nam = {}
        for i in range(1, ND + 1):
            lbl = labels.get(i, f"dim{i}")
            nam[i] = "HN" if "H" in lbl else (lbl[-1] if lbl else str(i))
        return ND, nam
    except subprocess.CalledProcessError as e:
        sys.exit(f"`showhdr -verb` failed: {e}")
    ND = None; nam = {}
    for line in text.splitlines():
        line = line.rstrip()
        if line.startswith("FILE:"):
            parts = line.split()
            ND = int(parts[parts.index("DIM:") + 1])
        if line.startswith("NAME:"):
            parts = line.split()
            for i in range(ND): nam[i+1] = "HN" if "H" in str(parts[i - ND]) else str(parts[i-ND])[-1]
    return ND, nam

def main(P5_path,spec_path,spec_type=None,out=None):
    ND, nam = (parse_showhdr(spec_path))
    P5 = np.atleast_2d(np.loadtxt(P5_path, dtype=float))
    if spec_type==None: spec_type = os.path.splitext(os.path.basename(spec_path))[0]
    if out is None: out = os.path.splitext(P5_path)[0] + '.peaks'
    with open(out,"w") as out:
        out.write(f"# Number of dimensions {ND}\n")
        out.write(f"#FORMAT xeasy{ND}D\n")
        for i in range(ND): out.write(f"#INAME {i+1} {nam[i+1]}\n")
        if ND == 3:
            out.write(f"#SPECTRUM {spec_type} {nam[1]} {nam[2]} {nam[3]}\n")
            for idx, row in enumerate(P5, start=1):
                if len(row) != ND+2: continue
                F3, F1, F2, p, i = row
                out.write(f"{idx:7d} {F2:7.3f} {F1:7.3f} {F3:7.3f} 1 U {p:11.3E} {i:10.3E} e 0     0     0     0\n" )

        if ND == 2:
            out.write(f"#SPECTRUM {spec_type} {nam[1]} {nam[2]}\n")
            for idx, row in enumerate(P5, start=1):
                if len(row) != ND+2: continue
                F1, F2, p, i = row
                out.write(f"{idx:7d} {F2:7.3f} {F1:7.3f} 1 U {p:11.3E} {i:10.3E} e 0     0     0\n" )

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Convert P5 (format text to CYANA .peaks")
    ap.add_argument("P5", help="Path to input .P5 file")
    ap.add_argument("-spec", required=True, help="Spectrum file to pass to `showhdr -verb` (e.g., HNCO.ft3 or .P3)")
    ap.add_argument("-spec_type", default=None, help="Override spectrum name printed in #SPECTRUM")
    ap.add_argument("-o", default=None, help="Output file path (optional).")
    args = ap.parse_args()

    main(args.P5, spec_path=args.spec,spec_type=args.spec_type, out=args.o)
